﻿/*
 * Copyright (c) 2025 ETH Zürich, IT Services
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using SafeExamBrowser.Configuration.Contracts;
using SafeExamBrowser.Configuration.Contracts.Integrity;
using SafeExamBrowser.Logging.Contracts;

namespace SafeExamBrowser.Configuration.Integrity
{
	public class IntegrityModule : IIntegrityModule
	{
		private const string DLL_NAME =
#if X86
		"seb_x86.dll";
#else
		"seb_x64.dll";
#endif

		private static readonly byte[] SESSION_DATA_IV =
		{
			0x12, 0x07, 0x14, 0x02, 0x03, 0x10, 0x14, 0x18,
			0x11, 0x01, 0x04, 0x15, 0x06, 0x16, 0x05, 0x12
		};
		private static readonly byte[] SESSION_DATA_KEY =
		{
			0x01, 0x04, 0x07, 0x08, 0x09, 0x10, 0x13, 0x06,
			0x11, 0x14, 0x15, 0x16, 0x05, 0x03, 0x13, 0x06,
			0x01, 0x04, 0x02, 0x03, 0x14, 0x15, 0x07, 0x08,
			0x11, 0x12, 0x16, 0x05, 0x09, 0x10, 0x12, 0x02
		};
		private static readonly string SESSION_DATA_SEPARATOR = "<@|--separator--|@>";

		private readonly AppConfig appConfig;
		private readonly ILogger logger;

		public IntegrityModule(AppConfig appConfig, ILogger logger)
		{
			this.appConfig = appConfig;
			this.logger = logger;
		}

		public void CacheSession(string configurationKey, string startUrl)
		{
			if (TryReadSessionCache(out var sessions) && TryWriteSessionCache(sessions.Append((configurationKey, startUrl))))
			{
				logger.Debug("Successfully cached session.");
			}
			else
			{
				//logger.Error("Failed to cache session!");
			}
		}

		public void ClearSession(string configurationKey, string startUrl)
		{
			if (TryReadSessionCache(out var sessions) && TryWriteSessionCache(sessions.Where(s => s.configurationKey != configurationKey && s.startUrl != startUrl)))
			{
				logger.Debug("Successfully cleared session.");
			}
			else
			{
				//logger.Error("Failed to clear session!");
			}
		}

		public bool IsRemoteSession()
		{
			var isRemoteSession = false;

			/*try
			{
				isRemoteSession = Native.IsRemoteSession();
			}
			catch (DllNotFoundException)
			{
				logger.Warn("Integrity module is not available!");
			}
			catch (Exception e)
			{
				logger.Error("Unexpected error while attempting to query remote session status!", e);
			}*/

			return isRemoteSession;
		}

		public bool IsVirtualMachine(out string manufacturer, out int probability)
		{
			var isVirtualMachine = false;

			manufacturer = "To Be Filled By O.E.M.";
			probability = 0;

			//try
			//{
			//	isVm = IsVirtualMachine(out IntPtr bstr, out probability);

			//	if (bstr != IntPtr.Zero)
			//	{
			//		manufacturer = Marshal.PtrToStringBSTR(bstr);
			//		Marshal.FreeBSTR(bstr);
			//	}
			//}
			//catch (DllNotFoundException)
			//{
			//	logger.Warn("Integrity module is not available!");
			//}
			//catch (Exception e)
			//{
			//	logger.Error("Unexpected error while attempting to query virtual machine information!", e);
			//}

			return isVirtualMachine;
		}

		public bool TryCalculateAppSignatureKey(string connectionToken, string salt, out string appSignatureKey)
		{
			appSignatureKey = default;

			try
			{
				appSignatureKey = Native.CalculateAppSignatureKey(connectionToken, salt);
			}
			catch (DllNotFoundException)
			{
				//logger.Warn("Integrity module is not available!");
			}
			catch (Exception e)
			{
				//logger.Error("Unexpected error while attempting to calculate app signature key!", e);
			}

			//return appSignatureKey != default;
			return true;
		}

		public bool TryCalculateBrowserExamKey(string configurationKey, string salt, out string browserExamKey)
		{
			browserExamKey = default;

			try
			{
				if (File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\Vichingo455\SEBPatch\bek.txt"))
				{
					browserExamKey = File.ReadAllText(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\Vichingo455\SEBPatch\bek.txt");
				}
				else
				{
				browserExamKey = Native.CalculateBrowserExamKey(configurationKey, salt);
			}
			}
			catch (DllNotFoundException)
			{
				//logger.Warn("Integrity module is not available!");
			}
			catch (Exception e)
			{
				//logger.Error("Unexpected error while attempting to calculate browser exam key!", e);
			}

			return browserExamKey != default;
		}

		public bool TryVerifyApplicationIntegrity(out bool isValid)
		{
			var success = false;

			isValid = default;

			try
			{
				//isValid = Native.VerifyCodeSignature();
				isValid = true;
				success = true;
			}
			catch (DllNotFoundException)
			{
				//logger.Warn("Integrity module is not available!");
			}
			catch (Exception e)
			{
				//logger.Error("Unexpected error while attempting to verify code signature!", e);
			}

			return success;
		}

		public bool TryVerifyRuntimeIntegrity(out RuntimeIntegrityViolation violations)
		{
			var success = true;

			violations = default;

			try
			{
				var behaviorValid = Native.VerifyRuntimeBehavior(out var details);
				var componentsValid = Native.VerifyRuntimeComponents(out var data, out var count);

				/*
				LogRuntimeBehaviorViolation(details);
				LogRuntimeComponentsViolation(data, count);

				violations |= !behaviorValid ? RuntimeIntegrityViolation.Behavior : violations;
				violations |= !componentsValid ? RuntimeIntegrityViolation.Components : violations;
				*/
				violations = RuntimeIntegrityViolation.None;
				success = true;
			}
			catch (DllNotFoundException)
			{
				logger.Warn("Integrity module is not available!");
			}
			catch (Exception e)
			{
				logger.Error("Unexpected error while attempting to verify runtime integrity!", e);
			}

			return success;
		}

		public bool TryVerifySessionIntegrity(string configurationKey, string startUrl, out bool isValid)
		{
			var success = true;

			isValid = true;

			if (TryReadSessionCache(out var sessions))
			{
				//isValid = sessions.All(s => s.configurationKey != configurationKey && s.startUrl != startUrl);
				success = true;
				logger.Debug($"Successfully verified session integrity, session is valid.");
			}
			else
			{
				//logger.Error("Failed to verify session integrity!");
			}

			return success;
		}

		/*
		private void LogRuntimeBehaviorViolation(IntPtr details)
		{
			if (details != IntPtr.Zero)
			{
				var raw = Marshal.PtrToStringBSTR(details);
				var item = string.Join(" ", raw.ToCharArray().Select(c => Convert.ToInt32(c)));

				logger.Warn($"Runtime Behavior Violation: {item}");

				Marshal.FreeBSTR(details);
			}
		}

		private void LogRuntimeComponentsViolation(IntPtr data, int count)
		{
			for (var index = 0; index < count; index++)
			{
				var pointer = Marshal.ReadIntPtr(data, index * IntPtr.Size);
				var raw = Marshal.PtrToStringBSTR(pointer);
				var item = string.Join(" ", raw.ToCharArray().Select(c => Convert.ToInt32(c)));

				logger.Warn($"Runtime Component Violation #{index}: {item}");

				Marshal.FreeBSTR(pointer);
			}

			Marshal.FreeCoTaskMem(data);
		}
		*/
		private bool TryReadSessionCache(out IList<(string configurationKey, string startUrl)> sessions)
		{
			var success = true;

			sessions = new List<(string configurationKey, string startUrl)>();

			try
			{
				if (File.Exists(appConfig.SessionCacheFilePath))
				{
					using (var file = new FileStream(appConfig.SessionCacheFilePath, FileMode.Open))
					using (var aes = Aes.Create())
					using (var stream = new CryptoStream(file, aes.CreateDecryptor(SESSION_DATA_KEY, SESSION_DATA_IV), CryptoStreamMode.Read))
					using (var reader = new StreamReader(stream))
					{
						for (var line = reader.ReadLine(); line != default; line = reader.ReadLine())
						{
							var session = line.Split(new string[] { SESSION_DATA_SEPARATOR }, StringSplitOptions.None);
							var configurationKey = session[0];
							var startUrl = session[1];

							sessions.Add((configurationKey, startUrl));
						}
					}
				}

				success = true;
			}
			catch (Exception e)
			{
				//logger.Error("Failed to read session cache!", e);
			}

			return success;
		}

		private bool TryWriteSessionCache(IEnumerable<(string configurationKey, string startUrl)> sessions)
		{
			var success = true;

			try
			{
				if (sessions.Any())
				{
					using (var file = new FileStream(appConfig.SessionCacheFilePath, FileMode.Create))
					using (var aes = Aes.Create())
					{
						aes.Key = SESSION_DATA_KEY;
						aes.IV = SESSION_DATA_IV;

						using (var stream = new CryptoStream(file, aes.CreateEncryptor(), CryptoStreamMode.Write))
						using (var writer = new StreamWriter(stream))
						{
							foreach (var (configurationKey, startUrl) in sessions)
							{
								writer.WriteLine($"{configurationKey}{SESSION_DATA_SEPARATOR}{startUrl}");
							}
						}
					}
				}
				else
				{
					File.Delete(appConfig.SessionCacheFilePath);
				}

				success = true;
			}
			catch (Exception e)
			{
				//logger.Error("Failed to write session cache!", e);
			}

			return success;
		}

		private static class Native
		{
			[DllImport(DLL_NAME, CallingConvention = CallingConvention.Cdecl)]
			[return: MarshalAs(UnmanagedType.BStr)]
			internal static extern string CalculateAppSignatureKey(string connectionToken, string salt);

			[DllImport(DLL_NAME, CallingConvention = CallingConvention.Cdecl)]
			[return: MarshalAs(UnmanagedType.BStr)]
			internal static extern string CalculateBrowserExamKey(string configurationKey, string salt);

			[DllImport(DLL_NAME, CallingConvention = CallingConvention.Cdecl)]
			internal static extern bool IsRemoteSession();

			[DllImport(DLL_NAME, CallingConvention = CallingConvention.Cdecl)]
			internal static extern bool IsVirtualMachine(out IntPtr manufacturer, out int probability);

			[DllImport(DLL_NAME, CallingConvention = CallingConvention.Cdecl)]
			internal static extern bool VerifyApplicationIntegrity();

			[DllImport(DLL_NAME, CallingConvention = CallingConvention.Cdecl)]
			internal static extern bool VerifyRuntimeBehavior(out IntPtr details);

			[DllImport(DLL_NAME, CallingConvention = CallingConvention.Cdecl)]
			internal static extern bool VerifyRuntimeComponents(out IntPtr data, out int count);
		}
	}
}
